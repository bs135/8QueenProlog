:-set_prolog_flag(singleton,off).
:-set_prolog_flag(redefine_builtin,on).

:-consult('c:/BProlog/cg/comp').
:-consult('c:/BProlog/cg/solve').
:-consult('c:/BProlog/cg/constr').
:-cl('c:/BProlog/cg/tree').
:-cl('c:/BProlog/cg/util').
:-cl('c:/BProlog/cg/show').
:-cl('c:/BProlog/cg/ide_util').
:-cl('c:/BProlog/cg/key').
:-cl('c:/BProlog/cg/operation').
